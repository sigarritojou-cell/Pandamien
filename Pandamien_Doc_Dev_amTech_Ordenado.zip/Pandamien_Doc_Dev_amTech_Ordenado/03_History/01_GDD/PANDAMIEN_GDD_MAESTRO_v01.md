
# PANDAMIEN — GDD MAESTRO INTEGRADO
## Versión ultra consolidada de visión, sistemas, narrativa, entorno y producción
### Documento maestro vivo de canon, diseño y preproducción

---

## 0. Estado del documento

Este documento sustituye al GDD canónico reformulado anterior como **versión maestra de trabajo**. Su función es consolidar en una única fuente:

- el high concept completo,
- la estructura día/noche,
- el apartamento como sistema total,
- el móvil diegético dentro del piso,
- la televisión como personaje y vector de manipulación,
- la lógica de evitación/confrontación,
- la mirilla, ventana y balcón como sistema de paranoia,
- el bosque narrativo con vínculos, diálogos, decisiones y ecos cruzados,
- la puerta atrancada y la habitación sellada como eje físico del horror,
- el sistema de contaminación por zonas y contención/limpieza parcial,
- la gestación física de la criatura a partir de residuos emocionales y ambientales,
- la definición del apartamento a nivel espacial, gráfico, interactivo y de colisiones,
- la macroestructura por actos y ciclos,
- los criterios de vertical slice, MVP y producción,
- la política explícita de **no usar IA en runtime**,
- y un sistema de documentación/versionado para evitar pérdida de información entre versiones.

Este documento no cierra todavía cada línea de diálogo ni cada escena final exacta. Sí cierra la base necesaria para producir el juego sin contradicciones graves.

---

# 1. Identidad del proyecto

## 1.1. High Concept

**PANDAMIEN** es una experiencia narrativa de horror psicológico íntimo en primera persona, ambientada durante el confinamiento de 2020 en España, dentro de un único apartamento.

El jugador vive un ciclo continuo de:

- **día**: presión social, emocional y mediática dentro del piso,
- **transición**: sedimentación del residuo del día,
- **noche**: deformación perceptiva, retorno de lo evitado, aparición progresiva de la presencia,
- **decisión**: responder, callar, posponer, medicarse, mirar, limpiar, contener, exponerse o retirarse,
- **consecuencia**: cambian las relaciones, cambia el apartamento, cambia el exterior percibido, cambia la criatura que se está gestando.

No hay game over tradicional. El jugador siempre progresa, pero progresa hacia una versión cada vez más deteriorada, íntima, reveladora o insoportable de sí mismo.

## 1.2. Frase canónica

**PANDAMIEN es un juego de encierro, culpa y percepción en el que un apartamento convierte los silencios, vínculos, dispositivos, umbrales y residuos del protagonista en una máquina íntima de horror psicológico que termina gestando una criatura al otro lado de una puerta sellada.**

## 1.3. Fantasía emocional del jugador

La fantasía jugable no es ser poderoso ni resolver un misterio al uso. Es:

- habitar el encierro,
- gestionar la presión afectiva y funcional,
- evitar o afrontar conversaciones,
- buscar consuelo en dispositivos que también contaminan,
- observar un exterior ambiguo que no puede verificarse del todo,
- intentar sostener el deterioro cotidiano del apartamento,
- decidir qué parte de la podredumbre atender y cuál sacrificar,
- sentir que lo que se deja pudrir adquiere cuerpo,
- llegar al final con una criatura que es, en parte, un inventario vivo de lo no atendido.

## 1.4. Emociones objetivo

- incomodidad sostenida,
- incertidumbre,
- culpa,
- hipervigilancia,
- soledad,
- vergüenza,
- desgaste,
- intimidad invadida,
- sensación de que el piso recuerda,
- sensación de que algo detrás de la puerta está creciendo.

---

# 2. Principios irrenunciables

## 2.1. Principios de diseño

1. **Sistema antes que ornamento**. Toda mecánica debe reforzar el conflicto central.
2. **El apartamento es el mundo completo**. Todo ocurre dentro, desde dentro o en relación con sus umbrales.
3. **No hacer también es jugar**. Ignorar, aplazar, callar, no limpiar o no mirar son decisiones.
4. **Sin game over tradicional**. Incluso las acciones extremas son absorbidas por la estructura.
5. **Sin jumpscares como columna vertebral**. La tensión nace de percepción, repetición, degradación y espera.
6. **La televisión es personaje**. No es mero ruido de fondo.
7. **El exterior existe, pero casi nunca puede verificarse por completo**.
8. **La criatura no aparece: se gesta**.
9. **La suciedad no es decorado: es anatomía potencial**.
10. **No IA en runtime**. El contenido final será autoral, cerrado y controlado.
11. **El horror debe ser más íntimo que espectacular**.
12. **Nunca habrá tiempo para arreglarlo todo**.

## 2.2. Prohibiciones

- No tutorializar el sentido del juego.
- No usar barras visibles de cordura o salud mental.
- No convertir la limpieza en un simulador doméstico.
- No introducir combate convencional.
- No resolver la tensión con puzles arbitrarios desconectados del conflicto emocional.
- No caer en “casa encantada” genérica.
- No convertir a la criatura en un boss de videojuego clásico.
- No usar IA generativa dentro de la experiencia final.
- No permitir un “estado limpio total” que anule el conflicto.

---

# 3. Equipo canónico de desarrollo

## 3.1. Dirección central

### Dirección Creativa
Responsabilidades:
- proteger la visión,
- aprobar o rechazar cambios,
- resolver conflictos entre áreas,
- garantizar coherencia emocional, sistémica y de producción.

---

## 3.2. Núcleo original

### Arquitectura Narrativa
- estructura dramática general,
- arcos emocionales,
- organización del bosque narrativo.

### Diseño de Sistemas
- variables,
- reglas,
- estados,
- consecuencias,
- balance entre presión y claridad.

### Ingeniería de Gameplay
- arquitectura técnica,
- máquinas de estado,
- persistencia,
- eventos condicionados.

### Dirección de Experiencia
- pacing,
- tensión,
- dosificación,
- progresión de incomodidad.

### Diseño de Entorno
- apartamento como sistema,
- zonificación,
- legibilidad espacial,
- transformación del espacio.

### Diseño de Interacción
- acciones del jugador,
- claridad del input,
- fricción con intención.

### Diseño TV / Meta-Narrativa
- TV como personaje,
- manipulación,
- biblioteca de líneas y formatos.

### Estrategia de Producción
- alcance,
- vertical slice,
- MVP,
- prioridades,
- control de creep.

---

## 3.3. Equipo ampliado de narrativa y contenido

### Lead Writer / Historia General
- arco completo,
- estructura de actos,
- hitos emocionales.

### Guionista de Diálogos
- voces de personajes,
- subtexto,
- registros verbales,
- recurrencias.

### Diseñadora de Relaciones
- evolución de cada vínculo,
- deuda emocional,
- tensiones de respuesta/silencio.

### Editora de Continuidad y Canon
- evitar contradicciones,
- revisar coherencia transversal.

### Diseñadora de Narrativa Sistémica
- convertir culpa, evitación y presión en reglas jugables.

### Diseñadora de Interfaces Diegéticas
- móvil,
- TV,
- llamadas,
- mensajes,
- notificaciones,
- visualización física dentro del mundo.

### Diseñadora de Umbrales y Exterioridad
- mirilla,
- ventana,
- balcón,
- rellano,
- calle,
- vecinos.

### Guionista de Fenómenos Vecinales
- vida del edificio,
- sonidos,
- escenas ambiguas del exterior.

### Diseñador/a de Presencia Antagónica
- identidad,
- fases,
- manifestaciones,
- relación entre criatura gestada y presencia percibida.

---

## 3.4. Equipo creativo de entorno y espacialidad

### Dirección de Arquitectura Espacial
- layout canónico del piso,
- circulación,
- proporciones,
- visuales internas.

### Diseño de Colisiones y Fisicalidad Doméstica
- navegación limpia,
- jerarquía de colisiones,
- fricción intencional.

### Lead de Props Narrativos
- objetos con carga dramática,
- estados de prop,
- semántica material.

### Diseño de Interacción Microdiegética
- abrir,
- cerrar,
- encender,
- apagar,
- mirar,
- escuchar,
- contener,
- limpiar.

### Art Direction del Deterioro
- desgaste,
- humedad,
- suciedad,
- moho,
- densidad visual por actos.

### Diseño de Iluminación Circadiana
- día,
- tarde,
- noche,
- TV glow,
- farolas,
- vecinos,
- contraste emocional.

### Diseño Sonoro Espacial del Piso
- electrodomésticos,
- tuberías,
- crujidos,
- patio,
- rellano,
- calle,
- focos de escucha.

### Diseño de Umbrales y Exterioridad Física
- puerta principal,
- mirilla,
- barandilla,
- ventanas,
- visibilidad parcial.

### Tech Art de Estados del Entorno
- cambios de materiales,
- swaps,
- degradación sutil,
- contaminación biológica,
- reflejos,
- TV.

### Continuidad Doméstica y Verosimilitud 2020
- credibilidad cultural y temporal del piso durante confinamiento.

---

## 3.5. Nuevo rol obligatorio de documentación

### Arquitecto/a de Documentación y Versionado Canónico
Responsabilidades:
- mantener el **GDD Maestro** como fuente única de verdad,
- registrar cada cambio aprobado en un changelog,
- propagar cambios a anexos y tablas dependientes,
- evitar que una idea aceptada desaparezca en versiones posteriores,
- marcar qué está congelado, provisional o abierto,
- vigilar nomenclatura, IDs, variables y plantillas,
- coordinar continuidad entre narrativa, sistemas, entorno y producción.

Reglas:
1. Ningún cambio entra en canon sin quedar reflejado en el GDD Maestro.
2. Toda modificación debe indicar:
   - fecha,
   - responsable,
   - sección afectada,
   - motivo,
   - impacto.
3. Toda sección tendrá estado:
   - **cerrado**,
   - **en desarrollo**,
   - **abierto**.
4. Ningún anexo podrá contradecir al GDD Maestro.
5. Cuando un sistema cambie, debe actualizarse también:
   - su tabla de variables,
   - su impacto en entorno,
   - su impacto narrativo,
   - y su impacto en producción.

---

# 4. Pilares temáticos

## 4.1. Encierro
El mundo se reduce al apartamento y a lo que puede percibirse desde sus bordes.

## 4.2. Evitación
El jugador no fracasa por falta de habilidad, sino por el coste acumulado de no sostener lo que duele.

## 4.3. Contaminación
Lo emocional, lo mediático, lo físico y lo espacial se contaminan entre sí.

## 4.4. Deuda
Toda llamada ignorada, toda mancha no contenida, todo gesto postergado deja residuo.

## 4.5. Gestación
La criatura no es sólo amenaza externa: es una consecuencia acumulativa y corporalizada.

---

# 5. Macroestructura del juego

## 5.1. Estructura base de ciclo

Cada ciclo se compone de:

1. **Día dentro del apartamento**
   - mensajes,
   - llamadas,
   - notas de voz,
   - tareas funcionales,
   - TV activa o latente,
   - focos de suciedad/contaminación,
   - observación del exterior,
   - posible contención/limpieza parcial.

2. **Transición**
   - la luz baja,
   - el ruido del edificio cambia,
   - el piso acusa recibo,
   - pueden consolidarse focos de contaminación,
   - la puerta sellada puede emitir primeros signos.

3. **Noche**
   - exploración del piso,
   - eventos ambientales,
   - TV contaminada,
   - umbrales activos,
   - presión de la criatura tras la puerta,
   - presencia indirecta o parcialmente encarnada.

4. **Cierre**
   - dormir,
   - medicarse,
   - resistir despierto,
   - asomarse,
   - contener una zona,
   - asumir una pérdida,
   - acción extrema contextual si existe.

5. **Persistencia**
   - cambian las relaciones,
   - cambian las zonas del piso,
   - cambian las líneas de la TV,
   - cambia el exterior percibido,
   - cambia la anatomía/temperamento de la criatura.

## 5.2. Estructura dramática por actos

### Acto I — Rutina contaminada
- piso creíble,
- TV compañera,
- puerta atrancada asumida como problema cotidiano,
- primeras deudas,
- primeras manchas plausibles,
- primer sonido tras la puerta al cierre de la primera noche.

### Acto II — Colonización
- el espacio reacciona,
- la TV personaliza,
- la suciedad se vuelve menos doméstica,
- los umbrales ganan espesor,
- la criatura empieza a tener funciones reconocibles.

### Acto III — Convergencia
- los lenguajes de editor, madre, amigo, ex, TV y exterior se mezclan,
- el jugador ya no sabe qué pertenece a quién,
- el piso se organiza alrededor de la puerta sellada,
- la criatura ya tiene presencia somática.

### Acto IV — Absorción / resolución
- la promesa de la puerta debe pagarse,
- ya no se trata de “curar el piso”, sino de decidir qué hacer con lo engendrado,
- el desenlace no limpia: revela, absorbe, sostiene o deja convivir con la grieta.

---

# 6. Estructura recomendada de ciclos

## 6.1. Recomendación

Para juego cerrado corto: **8 ciclos completos día/noche**.

## 6.2. Función de cada ciclo

### Ciclo 1 — Reconocimiento
- se establece rutina,
- se presenta puerta atrancada como detalle cotidiano,
- el jugador conoce los vínculos base,
- aparece el primer foco menor de desorden o humedad,
- primera noche: pequeño gemido o golpe torpe tras la puerta.

### Ciclo 2 — Primera deuda clara
- el editor aprieta,
- una zona ligada al trabajo se ensucia o densifica,
- se introduce primera contención simple,
- la criatura gana un primer rasgo funcional.

### Ciclo 3 — El cuerpo entra en juego
- madre/medicación,
- baño y dormitorio ganan peso,
- proliferan humedad, cansancio, descuido,
- la puerta reacciona con respiración o roce.

### Ciclo 4 — La herida íntima
- ex/pareja,
- dormitorio y balcón contaminados por intimidad suspendida,
- la criatura gana corazón, pecho o voz emocional.

### Ciclo 5 — El exterior se pega al piso
- mirilla, paquete, sombra, rellano, luces vecinas,
- una zona de umbral se pudre,
- la criatura gana ojos o atención dirigida.

### Ciclo 6 — Colonización semántica
- TV roba lenguaje de todos,
- la contaminación ya es cruzada,
- la criatura puede emitir frases, ritmos o masticaciones reconocibles.

### Ciclo 7 — Doble vínculo imposible
- dos presiones incompatibles,
- ya no hay modo de sostenerlo todo,
- el jugador sacrifica una parte del piso, un vínculo o una verdad,
- la puerta aguanta a duras penas.

### Ciclo 8 — Resolución
- el estado de la criatura y del piso reflejan el historial completo,
- se llega al umbral final de apertura, contención, ruptura o absorción.

---

# 7. El apartamento como sistema total

## 7.1. Regla maestra
El apartamento es el único escenario principal y el verdadero cuerpo del juego.

## 7.2. Zonas canónicas

- dormitorio,
- salón,
- pasillo,
- cocina,
- baño,
- balcón,
- puerta de entrada / mirilla,
- ventana o ventanas principales,
- **puerta atrancada / habitación sellada**.

## 7.3. Función dramática por zona

### Dormitorio
- refugio,
- recaída,
- sueño,
- medicación,
- deseo de desaparecer,
- intimidad herida.

### Salón
- TV,
- absorción pasiva,
- trabajo informal,
- autoengaño funcional.

### Pasillo
- compresión,
- tránsito,
- alineación con la puerta sellada,
- propagación de golpes, roces y peso.

### Cocina
- rutina corporal,
- hambre/no hambre,
- tiempo,
- descuido tangible.

### Baño
- cuerpo,
- espejo,
- vulnerabilidad,
- higiene imposible,
- crecimiento orgánico de humedad.

### Balcón
- exposición,
- aire,
- tentación de fuga,
- observación recíproca.

### Puerta / Mirilla
- proximidad del afuera,
- amenaza cotidiana,
- paquetes, bolsas, pasos, voces.

### Ventana
- distancia,
- patrón social,
- exterior narrativo y ambiguo.

### Puerta atrancada / Habitación sellada
- núcleo incubador,
- cámara de resonancia de residuos,
- promesa física del horror,
- lugar inaccesible durante la mayor parte del juego,
- destino parcial o total de la criatura.

## 7.4. Estados de objetos
Los objetos relevantes podrán existir en estados:

- normal,
- descuidado,
- contaminado,
- alterado,
- roto.

## 7.5. Regla de transformación
Siempre que sea posible, los cambios relevantes deben ocurrir:
- fuera de la visión del jugador,
- durante distracciones,
- entre día y noche,
- o en momentos de desatención.

El objetivo es privilegiar la sospecha sobre el espectáculo.

---

# 8. Apartamento canónico: layout, escala y circulación

## 8.1. Escala recomendada
Apartamento pequeño y verosímil, aprox. **68–72 m²**.

## 8.2. Layout recomendado

- Entrada desde rellano a un recibidor muy breve.
- Pasillo estrecho como espina dorsal.
- A un lado: baño y cocina.
- Al fondo o lateral del recorrido: dormitorio.
- Desembocadura del pasillo en salón-comedor.
- Balcón y ventana principal asociados al salón.
- Cocina con posible apertura parcial al salón.
- La puerta atrancada debe quedar en una posición de alto peso dramático:
  - preferiblemente **alineada o visible parcialmente desde el pasillo**,
  - nunca demasiado céntrica al principio,
  - nunca tan escondida que parezca olvidable.

## 8.3. Reglas de visibilidad

- Desde la cama no debe verse toda la puerta del dormitorio ni toda la de la habitación sellada.
- Desde el sofá no se domina completamente el pasillo.
- Desde la cocina se intuye el salón, pero no se controla.
- Desde el baño el espejo nunca da visión segura del resto del piso.
- La puerta atrancada debe poder sentirse presente aunque no se vea constantemente.

## 8.4. Jerarquía espacial
1. Dormitorio
2. Salón
3. Pasillo
4. Puerta atrancada
5. Baño
6. Cocina
7. Puerta principal / mirilla
8. Balcón
9. Ventana

La jerarquía puede variar por acto, pero el pasillo y la puerta atrancada deben ganar centralidad progresivamente.

---

# 9. Colisiones, navegación y fisicalidad

## 9.1. Filosofía
La navegación debe ser limpia y creíble. Nada de engancharse con basura pequeña ni de fricción accidental tonta.

## 9.2. Capas de colisión

### Estructural
- muros,
- suelos,
- techos,
- marcos,
- barandillas,
- encimeras fijas,
- sanitarios.

### Funcional
- sofá,
- mesa,
- cama,
- armario,
- puerta principal,
- puerta atrancada,
- nevera,
- botiquín,
- TV,
- ventanas operables.

### Semántica
- ropa,
- papeles,
- bolsas,
- props menores,
- residuos visuales,
- focos de moho,
- baba, costras, humedad localizada.

La capa semántica rara vez debe bloquear por completo. Su función principal es narrativa, perceptiva y selectivamente interactiva.

## 9.3. Reglas de movimiento

- Sin salto libre.
- Sin agachado salvo que una escena concreta lo requiera.
- Anchura mínima cómoda de paso: 80 cm.
- Puertas funcionales sólo donde aporten.
- Balcón bloqueado por barandilla siempre; la acción extrema será contextual, no movimiento libre.
- Los puntos de interacción prioritarios deben tener lectura clara.

## 9.4. Puerta atrancada
Debe tener:
- colisión robusta,
- audio propio,
- interacción limitada,
- pequeños cambios materiales por actos,
- capacidad de transmitir peso, presión, humedad o vibración.

No debe abrirse como puzzle de inventario estándar.

---

# 10. Sistema del día — móvil dentro del apartamento

## 10.1. Principio
El día no es un menú separado. Ocurre dentro del piso.

## 10.2. Posibles usos del móvil
- tumbado,
- sentado,
- de pie,
- junto a la TV,
- junto a la ventana,
- cerca de la puerta,
- cerca de un foco de suciedad,
- después de oír algo tras la puerta atrancada.

## 10.3. Entradas posibles
- mensajes,
- llamadas,
- notas de voz,
- notificaciones,
- historial,
- silencios,
- mensajes contaminados en fases avanzadas.

## 10.4. Vínculos base
- editor,
- madre,
- amigo,
- pareja o ex,
- contactos secundarios si procede,
- eco indirecto de la TV como pseudo vínculo.

## 10.5. Acciones del jugador
- responder directo,
- responder evasivo,
- posponer,
- ignorar,
- silenciar,
- colgar,
- abrir y no contestar,
- releer,
- desconectar temporalmente.

## 10.6. Regla de diseño
**No responder también es jugar.**

## 10.7. Acoplamiento con el entorno
Mientras el móvil está activo:
- la TV puede contaminar,
- el exterior puede sonar,
- un foco de suciedad puede volverse notable,
- la puerta atrancada puede emitir algo,
- una decisión de respuesta puede impedir o permitir una contención ambiental.

---

# 11. Sistema de relaciones

## 11.1. Objetivo
Cada vínculo no es sólo un personaje. Es una fuerza que tira del protagonista en una dirección distinta.

## 11.2. Personajes base

### Editor
- presión,
- utilidad,
- productividad,
- deuda laboral.

### Madre
- cuidado,
- control,
- medicalización,
- culpa filial.

### Amigo
- distracción,
- banalidad,
- refugio ruidoso,
- evasión social.

### Pareja / Ex
- herida,
- ambigüedad,
- deseo,
- reparación imposible.

## 11.3. Información obligatoria por vínculo
1. Qué quiere del protagonista.
2. Qué activa en él.
3. Cómo habla en estado cotidiano.
4. Cómo se distorsiona en estados alterados.
5. Qué zonas del piso tiñe.
6. Qué parte de la criatura puede alimentar por evitación.
7. Qué líneas puede robar la TV.
8. Qué forma puede tomar su eco en el exterior.

## 11.4. Estados relacionales mínimos
- fluido,
- tenso,
- aplazado,
- silencio cargado,
- roto parcialmente,
- contaminado/alucinado.

---

# 12. Sistema TV — personaje y vector de manipulación

## 12.1. Regla central
La televisión no es un aparato. Es un personaje-sistema.

## 12.2. Funciones
- acompañar,
- distraer,
- comentar indirectamente,
- sesgar interpretación,
- anestesiar,
- legitimar evitación,
- apropiarse del lenguaje de otros,
- confrontar.

## 12.3. Estados
1. Comfort
2. Suggestion
3. Manipulation
4. Confrontation

## 12.4. Relación con la puerta y la criatura
La TV no crea la criatura por sí sola, pero puede:
- justificar la inacción,
- sugerir descanso en vez de contención,
- trivializar el deterioro,
- nombrar de forma torcida lo que hay detrás de la puerta,
- convertir gemidos o golpes en “ruido normal”.

## 12.5. Regla de contaminación cruzada
La TV puede parasitar:
- temas de mensajes ignorados,
- presión laboral,
- lenguaje materno,
- tono de la ex,
- escenas vistas por la ventana,
- sonidos de la puerta atrancada.

---

# 13. Sistema de umbrales del encierro

## 13.1. Componentes
- mirilla,
- ventana,
- balcón.

## 13.2. Función
Conectar el interior con un exterior que existe, presiona y contagia, pero rara vez ofrece verdad plena.

## 13.3. Mirilla
- proximidad,
- deformación,
- poco contexto,
- presencia demasiado cerca.

## 13.4. Ventana
- distancia,
- relato social,
- repetición,
- ambigüedad.

## 13.5. Balcón
- exposición,
- ventilación falsa,
- contacto limitado,
- tentación de fuga,
- posible acción extrema.

## 13.6. Regla maestra
El exterior nunca aclara del todo. Sólo presiona, refleja, tienta o miente.

## 13.7. Cruce con la criatura
A medida que la criatura crece, el exterior puede:
- reflejar partes suyas,
- anticiparlas simbólicamente,
- devolver ecos de voz, mirada o respiración,
- mostrar figuras que parecen invocar lo que está gestándose dentro.

---

# 14. La puerta atrancada y la habitación sellada

## 14.1. Principio
Debe existir una puerta atrancada, asociada a una habitación inaccesible. Al principio se lee como un problema cotidiano del piso:
- una maldita puerta que habría que arreglar,
- un marco hinchado,
- una puerta vieja atascada,
- algo normalizado.

No debe empezar con halo explícito de “cuarto maldito”.

## 14.2. Función dramática
La puerta atrancada:
- da una promesa física al juego,
- centraliza la ansiedad del apartamento,
- convierte la degradación del piso en un proceso con destino,
- materializa la gestación de la criatura,
- concentra el deseo de ver y el miedo a abrir.

## 14.3. Regla de inaccesibilidad
Durante la mayor parte del juego:
- no se abre de forma normal,
- no se fuerza con puzzle clásico,
- no se desbloquea por inventario arbitrario,
- se explora desde fuera: oído, vibración, humedad, presión, golpes, olor, marco, sombra bajo la rendija si conviene.

## 14.4. Evolución
- Acto I: problema doméstico.
- Acto II: fuente de sonidos dudosos.
- Acto III: cámara de gestación evidente.
- Acto IV: umbral de resolución.

---

# 15. Sistema de contaminación por zonas

## 15.1. Definición
La contaminación es la manifestación física y progresiva del residuo emocional, funcional y conductual del jugador.

No es sólo suciedad. Puede ser:
- humedad,
- moho,
- costra,
- restos orgánicos dudosos,
- desorden con carga,
- goteo,
- baba,
- olor,
- ennegrecimiento,
- manchas que parecen querer forma,
- deterioro material, textil o biológico.

## 15.2. Fuentes de contaminación
- silencios prolongados,
- deuda social,
- evitación,
- exceso de TV,
- descuido corporal,
- tareas no atendidas,
- fijación obsesiva con umbrales,
- medicación como corte repetido,
- noches mal cerradas,
- exposición fallida al exterior.

## 15.3. Reglas maestras
1. La contaminación aparece por zonas, no sólo globalmente.
2. Nunca podrá limpiarse todo.
3. Cada foco no contenido alimenta la criatura.
4. La contaminación debe empezar creíble y volverse gradualmente anómala.
5. Su lectura debe ser doméstica antes que monstruosa.

## 15.4. Variables de zona recomendadas
- `zone_contamination_bedroom`
- `zone_contamination_living`
- `zone_contamination_hall`
- `zone_contamination_kitchen`
- `zone_contamination_bathroom`
- `zone_contamination_balcony`
- `zone_contamination_entry`

## 15.5. Estados de zona
- limpia / neutra,
- descuidada,
- degradada,
- contaminada,
- incubadora activa,
- sacrificada.

## 15.6. Focos típicos por zona

### Dormitorio
- ropa húmeda,
- lado de cama hundido,
- polvo agrio,
- latido en colchón,
- mancha en tela,
- aire espeso.

### Salón
- vaso abandonado,
- cenicero,
- polvo electrónico,
- restos junto al sofá,
- luz de TV enfermiza,
- costra detrás del mueble.

### Pasillo
- pared rozada,
- humedad alta,
- marcas verticales,
- fibras oscuras,
- golpes en el zócalo.

### Cocina
- bolsas,
- fregadero,
- restos,
- nevera,
- goteos,
- olor.

### Baño
- moho realista,
- silicona negra,
- espejo sucio,
- toalla húmeda,
- desagüe,
- baba en juntas.

### Balcón
- colillas,
- agua estancada,
- plantas medio muertas,
- suciedad arrastrada por aire,
- tela o plástico adherido.

### Entrada
- felpudo,
- bolsa olvidada,
- polvo de rellano,
- goteo junto a puerta,
- sombra bajo marco.

---

# 16. Sistema de contención / limpieza parcial

## 16.1. Filosofía
La limpieza no es una tarea doméstica completa. Es una **contención ritual, precaria y estratégica**.

## 16.2. Qué puede hacer el jugador
- retirar una bolsa,
- rascar una junta con moho,
- limpiar una mancha puntual,
- ventilar una zona,
- tirar un objeto podrido,
- cambiar una toalla o tela,
- secar una filtración,
- aislar un foco con cinta, trapo o improvisación,
- mover un prop que estaba alimentando una zona.

## 16.3. Qué no puede hacer
- dejar el piso perfecto,
- resetear toda la contaminación del ciclo,
- limpiar sin coste temporal o emocional.

## 16.4. Regla temporal
Por ciclo sólo debe haber capacidad para un número **limitado y doloroso** de intervenciones significativas.

## 16.5. Costes posibles de una contención
- perder tiempo para responder a alguien,
- dejar de atender una llamada,
- exponerse a la noche sin prepararse,
- bajar estabilidad,
- subir confrontation,
- activar un evento de puerta,
- empeorar otra zona por desatención.

## 16.6. Tipos de resultado
- contención exitosa,
- contención parcial,
- contención demasiado tardía,
- contención que desplaza el problema a otra zona,
- contención que reduce anatomía futura,
- contención que cambia el temperamento de la criatura.

---

# 17. La criatura gestada

## 17.1. Principio
La criatura no es sólo una presencia abstracta ni sólo una alucinación. Es una **gestación física y funcional** alimentada por las zonas descuidadas del apartamento y por los residuos de las decisiones del jugador.

## 17.2. Naturaleza
Es:
- condensación de culpa,
- anatomía de lo no atendido,
- cuerpo hecho de residuo,
- consecuencia íntima y espacial,
- monstruo físico sin dejar de ser metáfora.

## 17.3. Relación con la presencia
La “presencia” del juego puede operar en dos registros simultáneos:
1. **Presencia percibida**: ecos, sombras, ritmos, imitaciones, voces, figura incompleta.
2. **Criatura gestada**: cuerpo que se está formando detrás de la puerta atrancada.

Ambos registros pueden solaparse y contaminarse.

## 17.4. Fases
1. Latencia
2. Insinuación
3. Formación funcional
4. Encarnación parcial
5. Presión física sobre la puerta
6. Umbral final

---

# 18. Anatomía funcional de la criatura por zonas

## 18.1. Regla
Cada zona no contenida no genera una “pieza coleccionable”, sino una **función anatómica o expresiva** de la criatura.

## 18.2. Mapeo recomendado

### Salón / TV → Voz, garganta, discurso
Se alimenta de:
- pasividad,
- horas de TV,
- evasión verbal,
- autojustificación.

Manifestaciones:
- gemidos vocales,
- frases mal dichas,
- timbres robados,
- respiración en clave de locutor,
- comentarios desde detrás de la puerta.

### Entrada / Mirilla / Ventana → Ojos, atención, mirada
Se alimenta de:
- hipervigilancia,
- mirar sin actuar,
- obsesión con ser observado,
- exterior sin digestión.

Manifestaciones:
- sensación de mirada,
- brillo bajo rendija,
- sombras a altura errónea,
- quietud consciente.

### Pasillo → Piernas, columna, desplazamiento
Se alimenta de:
- compresión,
- tránsito ansioso,
- miedo a cruzar,
- escucha inmóvil.

Manifestaciones:
- golpes largos,
- cambio de peso,
- arrastres,
- presión vertical en madera.

### Cocina → Estómago, hambre, bilis
Se alimenta de:
- bolsas,
- restos,
- desorden corporal,
- ritmo alimenticio roto.

Manifestaciones:
- digestión,
- gorgoteo,
- masticación,
- líquidos,
- olor agrio.

### Baño → Piel, moho, mucosa, infección
Se alimenta de:
- humedad,
- descuido corporal,
- espejo evitado,
- higiene imposible.

Manifestaciones:
- baba,
- costra,
- piel húmeda,
- crecimiento de membrana.

### Dormitorio → Corazón, pecho, latido, intimidad
Se alimenta de:
- recaída,
- letargo,
- intimidad evitada,
- duelo afectivo.

Manifestaciones:
- latido,
- respiración de sueño,
- hundimiento,
- impulso emocional.

### Balcón → Pulmones, aire, exposición
Se alimenta de:
- falsas huidas,
- alivio parcial,
- deseo de lanzarse o escapar sin resolver.

Manifestaciones:
- jadeo,
- inhalación pesada,
- exhalaciones tras la puerta,
- presión torácica.

## 18.3. Temperamento emergente
La **rabia** no es una pieza fija; es un modo de activación de la criatura. Surge de:
- avoidance alta,
- social_debt alta,
- múltiples zonas sacrificadas,
- TV influyente,
- contención mínima o inútil.

Temperamentos posibles:
- doliente,
- imitativo,
- famélico,
- rencoroso,
- furioso,
- suplicante.

---

# 19. Comportamiento de la puerta por crecimiento de la criatura

## 19.1. Señales tempranas
- un gemido,
- un golpe torpe,
- roce leve,
- humedad en el marco,
- crujido.

## 19.2. Señales medias
- respiración,
- vocalización defectuosa,
- arrastre,
- sombra bajo puerta,
- vibración leve,
- olor.

## 19.3. Señales avanzadas
- presión de peso,
- embestida,
- uso involuntario o casi coordinado del cuerpo,
- golpes específicos según anatomía formada,
- intento de imitación verbal.

## 19.4. Regla
Lo que se oye de noche depende de qué partes se han formado y de qué temperamento domina.

Ejemplos:
- voz formada → sílabas, frases rotas, eco de llamadas.
- piernas formadas → golpes de longitud irregular.
- ojos formados → silencio denso y sensación de ser observado.
- hambre formada → masticación, líquidos.
- corazón formado → latido y respiración íntima.

---

# 20. Variables maestras y derivadas

## 20.1. Variables maestras

### `avoidance`
Tendencia a callar, aplazar, medicarse, evitar mirar o dejar sin contener.

### `confrontation`
Capacidad o impulso de sostener, responder, mirar, limpiar, exponerse.

### `tv_influence`
Grado en que la TV contamina interpretación y conducta.

### `editor_pressure`
Carga laboral y productiva.

### `stability`
Capacidad de sostener percepción y lectura de realidad.

## 20.2. Variables derivadas

### `social_debt`
Deuda por silencios, rechazos, conversaciones inconclusas.

### `guilt_noise`
Ruido mental de culpa, anticipación y vergüenza.

### `loneliness_index`
Aislamiento agudizado por autoexclusión.

### `threat_intimacy`
Grado en que la amenaza conoce y usa lo personal.

## 20.3. Variables nuevas de puerta/criatura

### `creature_growth`
Crecimiento global del cuerpo gestado.

### `door_pressure`
Tensión física ejercida sobre la puerta atrancada.

### `creature_temperament`
Modo dominante actual de la criatura.

### `containment_capacity`
Capacidad disponible de intervención por ciclo.

## 20.4. Variables de zona
Ver sección 15.4.

---

# 21. Reglas sistémicas globales

## 21.1. Relaciones generales
- mayor `avoidance` = más deuda, menos claridad, más contaminación, más crecimiento de criatura.
- mayor `confrontation` = noches más duras, más verdad, posible reducción de crecimiento o cambio de temperamento.
- mayor `tv_influence` = peores decisiones de contención e interpretación sesgada de puerta/exterior.
- menor `stability` = mezcla entre voz de criatura, TV, móvil y exterior.
- mayor `social_debt` = la criatura usa mejor las voces ajenas.
- mayor `zone_contamination_*` = más anatomía funcional disponible.

## 21.2. Regla central de dificultad
La dificultad no aumenta por daño arcade, sino por:
- pérdida de tiempo,
- pérdida de anclas,
- corrupción del espacio,
- deuda emocional,
- ambigüedad,
- presión física de la puerta,
- imposibilidad de atenderlo todo.

---

# 22. Bosque narrativo

## 22.1. Definición
La narrativa no se organiza como una línea única, sino como un bosque de troncos interdependientes.

## 22.2. Troncos principales

### Tronco A — Trabajo / deuda / productividad
Personaje ancla: editor.
Zonas: salón, mesa, portátil, reloj.
Anatomía alimentada: voz, mandíbula de exigencia, ritmo de presión.

### Tronco B — Cuidado / control / medicación
Personaje ancla: madre.
Zonas: baño, dormitorio.
Anatomía alimentada: pecho, piel, dependencia química, latido.

### Tronco C — Evasión / ruido / banalidad
Personaje ancla: amigo.
Zonas: salón, cocina.
Anatomía alimentada: garganta deformada, ruido, hambre difusa.

### Tronco D — Intimidad / herida / reparación imposible
Personaje ancla: ex/pareja.
Zonas: dormitorio, balcón.
Anatomía alimentada: corazón, respiración, voz herida.

### Tronco E — Exterioridad / paranoia / umbral
Sistema ancla: mirilla, ventana, balcón, puerta principal.
Zonas: entrada, pasillo, salón.
Anatomía alimentada: ojos, piernas, orientación del cuerpo.

## 22.3. Regla
La TV no es un tronco aparte. Es el vector fúngico que coloniza todos los troncos.

---

# 23. Árboles de diálogo y decisión

## 23.1. Regla de nodo
Toda conversación debe contemplar, como mínimo:
- respuesta directa,
- respuesta evasiva,
- respuesta diferida,
- silencio o no respuesta.

## 23.2. Efectos posibles de un nodo
- variables emocionales,
- estado relacional,
- eco en TV,
- eco en noche,
- eco en exterior,
- aparición o crecimiento de foco de contaminación,
- modificación de capacidad de contención del ciclo.

## 23.3. Plantilla oficial de nodo

```yaml
node_id: ""
character: ""
phase: "day"
context: ""
text: ""
subtext: ""
location_bias: ""
related_zone: ""
player_options:
  - option_id: ""
    label: ""
    tone: "direct / evasive / delay / silence"
    effects:
      avoidance: 0
      confrontation: 0
      social_debt: 0
      guilt_noise: 0
      loneliness_index: 0
      tv_influence: 0
      editor_pressure: 0
      stability: 0
      creature_growth: 0
      door_pressure: 0
      zone_contamination_bedroom: 0
      zone_contamination_living: 0
      zone_contamination_hall: 0
      zone_contamination_kitchen: 0
      zone_contamination_bathroom: 0
      zone_contamination_balcony: 0
      zone_contamination_entry: 0
    unlocks: []
    locks: []
    next_node: ""
echoes:
  tv: []
  night: []
  exterior: []
notes: ""
```

## 23.4. Plantilla de relación

```yaml
relationship_id: ""
character: ""
baseline_dynamic: ""
wants_from_player: ""
triggers_in_player: ""
speech_style: ""
distorted_echo_style: ""
favored_zones: []
feeds_creature_functions: []
tv_parasitic_topics: []
exterior_echoes: []
```

---

# 24. Sistema de eventos

## 24.1. Tipos de evento
- evento de móvil,
- evento relacional,
- evento de TV,
- evento ambiental,
- evento de umbral,
- evento de contaminación,
- evento de contención,
- evento de puerta,
- evento de criatura,
- evento de transición,
- evento de consecuencia.

## 24.2. Regla de orquestación
Los eventos no deben sentirse aleatorios. Responden a:
- fase del ciclo,
- variables,
- ubicación,
- historial,
- estado de zonas,
- estado de puerta,
- ritmo emocional.

## 24.3. Sistema recomendado
Contenido authored con:
- condiciones,
- pesos,
- prioridades,
- exclusiones,
- bloques temporales,
- tablas por fase y zona.

No generación libre.

---

# 25. Noche — exploración y confrontación

## 25.1. Objetivo
La noche encarna el precio del día y revela el estado del apartamento.

## 25.2. Acciones principales
- moverse,
- mirar,
- escuchar,
- abrir/cerrar,
- encender/apagar,
- usar objeto,
- observar umbrales,
- contener un foco si está permitido,
- acercarse a la puerta sellada,
- dormir o medicarse,
- resistir despierto.

## 25.3. Eventos base
- retardo de luz,
- puerta en estado extraño,
- TV encendida sola,
- vibración sin móvil,
- sonido bajo la puerta,
- moho más expandido,
- olor,
- repetición anómala de ruidos,
- eco de conversación diurna,
- presión de la criatura.

## 25.4. Evolución nocturna
### Temprana
- coincidencias perturbadoras,
- roces,
- sospecha.

### Media
- contaminación entre móvil, TV, exterior y puerta,
- zonas activas,
- partes de criatura reconocibles.

### Avanzada
- ocupación del piso por el historial acumulado,
- criatura casi presente físicamente,
- puerta al límite.

---

# 26. Medicación, sueño y evitación material

## 26.1. Medicación
No es sólo recurso funcional. Puede significar:
- alivio,
- rendición,
- obediencia,
- corte artificial del proceso,
- desplazamiento del horror,
- pacto temporal con la madre o con uno mismo.

## 26.2. Efectos posibles
- recortar secuencia nocturna,
- subir avoidance,
- alterar stability de forma ambigua,
- bloquear una contención,
- amortiguar una zona mientras otra empeora,
- cambiar el temperamento de la criatura de furioso a doliente, o viceversa.

## 26.3. Dormir
Dormir no cierra el nivel de forma neutra. Dormir es aceptar convivir con lo que queda detrás de la puerta.

---

# 27. Consecuencias persistentes

## 27.1. Fuentes
- respuestas y silencios,
- tiempo ante la TV,
- observación de exterior,
- medicación,
- contención/limpieza parcial,
- eventos nocturnos,
- atención o abandono de focos,
- exposición a la puerta,
- acciones extremas.

## 27.2. Efectos persistentes

### Relaciones
- insistencia,
- frialdad,
- dolor,
- agresividad pasiva,
- ternura más torcida.

### Apartamento
- nuevas zonas seguras o inseguras,
- contaminación persistente,
- rutas de tránsito más tensas.

### TV
- tono,
- biblioteca,
- grado de personalización.

### Puerta / criatura
- sonidos,
- humedad,
- presión,
- funciones anatómicas.

### Exterior
- escenas más dudosas,
- sincronías,
- vaciado o exceso social.

---

# 28. Biblioteca de sonidos de la puerta según estado

## 28.1. Banco temprano
- gemido breve,
- golpe torpe,
- roce leve,
- madera cediendo.

## 28.2. Banco medio
- respiración,
- clic húmedo,
- arrastre corto,
- uña o roce de superficie,
- sílaba incompleta.

## 28.3. Banco avanzado
- embestida,
- desplazamiento de masa,
- masticación,
- latido,
- frase robada,
- exhalación pegada a la rendija.

---

# 29. Apartado audiovisual

## 29.1. Visual
- realismo estilizado,
- pocos elementos pero significativos,
- degradación gradual,
- moho y suciedad plausibles antes que expresionismo gratuito,
- cambios sutiles de materialidad.

## 29.2. Audio
El audio es esencial:
- TV,
- tuberías,
- ciudad lejana,
- vecinos,
- patio,
- timbres,
- respiración,
- puerta atrancada,
- electrodomésticos,
- crujidos,
- vacío.

## 29.3. Regla
El sonido puede insinuar más que la imagen.

## 29.4. Color y luz por acto
### Acto I
- tonos cotidianos,
- beige,
- gris cálido,
- fluorescente doméstico,
- exterior normalizado.

### Acto II
- azules de TV,
- sombras más densas,
- brillo húmedo.

### Acto III
- contraste más nervioso,
- piel del piso más cansada,
- negros húmedos.

### Acto IV
- intimidad excesiva,
- el piso sigue siendo el piso, pero demasiado presente.

---

# 30. UX e interfaz

## 30.1. Principios
- todo lo posible debe ser diegético,
- el móvil debe sentirse objeto físico,
- la TV no debe parecer HUD,
- no mostrar medidores explícitos de culpa o monstruo.

## 30.2. Requisitos prácticos
- feedback suficiente para puntos interactivos prioritarios,
- accesibilidad básica,
- claridad al contener/limpiar un foco,
- diferenciación sonora y visual entre zona degradada y zona incubadora activa.

---

# 31. Implementación técnica

## 31.1. Sistemas recomendados
- máquina de estado global día / transición / noche / cierre,
- gestor de variables persistentes,
- sistema de zonas,
- sistema de focos de contaminación,
- sistema de contención limitada,
- sistema de crecimiento funcional de criatura,
- gestor de puerta atrancada,
- árboles de diálogo authored,
- biblioteca de líneas TV por fase,
- sistema de ecos en exterior,
- guardado por ciclo y checkpoints suaves.

## 31.2. Objeto técnico “puerta atrancada”
Debe soportar:
- múltiples estados visuales,
- banco sonoro contextual,
- lectura de variables de criatura,
- reacciones materiales,
- posibilidad de estado final de apertura, rotura o permanencia.

## 31.3. No IA en runtime
El juego final no usará:
- generación textual viva,
- decisiones dramáticas delegadas a modelos,
- síntesis narrativa autónoma.

La IA sólo podrá usarse en desarrollo para:
- ideación,
- estructuración,
- apoyo documental,
- clasificación,
- prototipado fuera del runtime.

---

# 32. Vertical slice

## 32.1. Objetivo
Demostrar la identidad real del proyecto.

## 32.2. Debe incluir
- apartamento base jugable,
- layout canónico funcional,
- móvil diegético,
- al menos 3 vínculos,
- TV con 2 estados,
- mirilla y ventana funcionales,
- balcón en momento controlado,
- puerta atrancada visible e interactuable de forma limitada,
- mínimo 2 focos de contaminación,
- una contención significativa,
- primer sonido tras la puerta,
- una noche con presencia indirecta,
- una noche con criatura más activa,
- persistencia al día siguiente.

## 32.3. No necesita todavía
- todas las ramas,
- confrontación final completa,
- modelado total de la criatura,
- todos los eventos de exterior.

---

# 33. MVP y juego completo

## 33.1. MVP jugable
- 2 o 3 ciclos,
- 2 o 3 zonas activas fuertes,
- 2 focos de contaminación recurrentes,
- puerta atrancada operativa,
- primer crecimiento funcional,
- TV contaminante,
- variables persistentes básicas.

## 33.2. Juego cerrado completo
- 8 ciclos,
- bosque narrativo completo,
- todas las zonas con foco potencial,
- criatura funcional completa o suficientemente variable,
- resolución coherente con el historial,
- finales o estados de cierre definidos.

---

# 34. Riesgos de diseño

## 34.1. Creativos
- volver demasiado literal el sistema de suciedad,
- convertir la limpieza en rutina aburrida,
- hacer de la criatura una suma demasiado mecánica de piezas,
- explicar demasiado pronto lo de la puerta,
- romper la sutileza con espectáculo barato.

## 34.2. De producción
- escribir demasiados diálogos sin IDs y sin estructura,
- dispersarse en demasiados personajes,
- sobrediseñar el exterior,
- no fijar nomenclatura de zonas y variables,
- dejar el versionado en manos de la memoria.

## 34.3. Técnicos
- acoplamiento excesivo entre sistemas,
- dificultad para sincronizar contaminación, criatura y diálogos,
- falta de herramientas internas para inspeccionar estado del piso por ciclo.

---

# 35. Preguntas abiertas controladas

Estas preguntas pueden seguir abiertas sin romper el canon ya fijado:

1. ¿Qué forma exacta toma la confrontación final con la criatura?
2. ¿Se abre la puerta, se rompe o ambas opciones dependen del estado?
3. ¿Qué nivel máximo de visibilidad corporal tendrá la criatura?
4. ¿Qué tipo de resoluciones finales habrá exactamente?
5. ¿Hasta qué punto la criatura puede salir de la habitación sellada antes del final?
6. ¿La acción extrema del balcón se integra en una ruta concreta o se mantiene como posibilidad excepcional?
7. ¿Qué partes del exterior serán siempre fiables y cuáles podrán mentir?

---

# 36. Estado de cierre actual

## 36.1. Congelado
- high concept,
- apartamento como sistema total,
- día/noche,
- móvil dentro del piso,
- TV como personaje,
- evitación/confrontación,
- umbrales de exterioridad,
- puerta atrancada y habitación sellada,
- contaminación por zonas,
- contención/limpieza parcial,
- criatura gestada por residuos,
- no IA en runtime,
- necesidad de control documental/versionado.

## 36.2. En desarrollo
- árboles completos de diálogo,
- fichas detalladas de 8 ciclos,
- biblioteca completa de TV,
- banco completo de fenómenos de exterior,
- gramática exacta de finales.

## 36.3. Abierto
- confrontación final exacta,
- corporalidad máxima de la criatura,
- número definitivo de finales,
- duración objetivo exacta.

---

# 37. Protocolo de documentación y versionado

## 37.1. Convención de nombre del documento
`PANDAMIEN_GDD_MAESTRO_vNN.md`

## 37.2. Convención de cambios
Cada versión nueva deberá incluir al inicio:

- número de versión,
- fecha,
- cambios principales,
- secciones afectadas,
- elementos congelados o desbloqueados.

## 37.3. Registro mínimo por cambio
```yaml
change_id: ""
date: ""
author_role: ""
summary: ""
sections_affected: []
reason: ""
production_impact: ""
canon_status: "closed / in_development / open"
```

## 37.4. Regla de preservación
Nada aprobado desaparece. Si una idea deja de ser canon:
- no se borra sin rastro,
- se mueve a descartes o historial,
- se registra motivo.

---

# 38. Anexos operativos reservados

## Anexo A — Biblia de personajes
Pendiente.

## Anexo B — Biblia de diálogos
Pendiente.

## Anexo C — Árboles de decisiones por personaje
Pendiente.

## Anexo D — Fichas de ciclos día por día
Pendiente.

## Anexo E — Fichas de noches
Pendiente.

## Anexo F — Biblioteca de líneas TV por fase
Pendiente.

## Anexo G — Banco de fenómenos del exterior
Pendiente.

## Anexo H — Diseño detallado de la criatura
Pendiente.

## Anexo I — Tabla de efectos cruzados
Pendiente.

## Anexo J — Apartamento canónico: layout, colisiones, props e interacciones
Pendiente.

## Anexo K — Manual de contaminación por zonas y contención
Pendiente.

## Anexo L — Changelog canónico
Pendiente.

---

# 39. Tabla semilla de efectos cruzados

| Acción del jugador | Variables afectadas | Zona afectada | Parte/función de criatura | Eco TV | Eco noche | Eco exterior | Efecto relacional |
|---|---|---|---|---|---|---|---|
| Ignorar llamada de la madre | avoidance+, social_debt+, guilt_noise+ | baño/dormitorio | piel o corazón | tono clínico e invasivo | respiración rara, humedad | bolsa o sombra en rellano | madre insistente o herida |
| Responder evasivo al editor | avoidance+, editor_pressure+ | salón | voz o mandíbula de exigencia | discurso de productividad falsa | zumbido de portátil, golpe seco | luces sincronizadas | editor más agresivo |
| Quedarse mirando la mirilla | threat_intimacy+, stability- | entrada/pasillo | ojos | tertulia sobre vigilancia | silencio denso en puerta | figura quieta fuera | más aislamiento |
| No limpiar fregadero / basura | zone_contamination_kitchen+, creature_growth+ | cocina | estómago/hambre | programa culinario desagradable | masticación o gorgoteo | olor en patio o vecino tirando algo | amigo banaliza, jugador se irrita |
| Limpiar moho del baño | confrontation+, stability- o + | baño | frena piel/mucosa | TV relativiza o ridiculiza el esfuerzo | menos baba, más golpe en otra zona | exterior amortiguado temporalmente | madre cambia tono |
| Salir al balcón tras discusión íntima | confrontation+, loneliness_index+/- | balcón/dormitorio | pulmones o corazón | TV juzga o romantiza | jadeo desde la puerta | eco de voz en patio | vínculo suspendido |
| Tomar medicación | avoidance+, stability +/- | dormitorio/baño | cambia temperamento | TV dulcificada | noche recortada pero deuda futura | exterior amortiguado | relación con madre muta |

---

# 40. Cierre de dirección creativa

Este GDD fija la versión más completa del proyecto hasta el momento. A partir de aquí, toda expansión debe justificarse en relación con el conflicto central y con el alcance de producción.

Nada nuevo debe entrar si:
- diluye la intimidad del horror,
- reduce el papel del apartamento,
- rompe la lógica de la puerta y la gestación,
- convierte el juego en una sucesión de tareas o sustos,
- o introduce sistemas que no dialogan con culpa, evitación, contaminación y cuerpo.

La regla final del proyecto es sencilla:

**el piso recuerda, el jugador elige qué dejar pudrirse, y eso acaba respirando al otro lado de una puerta.**
